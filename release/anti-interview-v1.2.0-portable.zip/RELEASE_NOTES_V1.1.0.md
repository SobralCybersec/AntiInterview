# Anti-Interview v1.1.0 - Release Notes

## Release Date: March 31, 2026

---

## New Features

### AI Browser Integration
- **Embedded Browser Window**: Access AI platforms without opening external browser
  - ChatGPT (https://chatgpt.com)
  - Antigravity (https://antigravity.ai)
  - Gemini (https://gemini.google.com)
  - Claude (https://claude.ai)
- **Borderless Windows**: Professional appearance with custom title bar
- **Process Monitoring**: Automatic state synchronization when browser closes
- **Auto-Hide Support**: Automatically hide AI browser windows from screen capture

### Silent Screenshot with Clipboard
- **New Hotkey**: `Ctrl+Shift+P` for silent screenshot
- **Clipboard Integration**: Automatically copies image to clipboard (not file path)
- **Configurable**: Toggle auto-paste in settings
- **RGBA Format**: Full color support with alpha channel
- **Temp File Storage**: Screenshots saved to temp directory with timestamp

### Enhanced Hotkey System
- **7 Configurable Hotkeys**:
  - `Ctrl+Shift+S` - Normal screenshot
  - `Ctrl+Shift+P` - Silent screenshot (clipboard copy)
  - `Ctrl+Shift+H` - Hide selected window
  - `Ctrl+Shift+I` - Show/Hide GUI
  - `Ctrl+Shift+R` - Refresh window list
  - `Ctrl+Shift+V` - Toggle preview
  - `Ctrl+Shift+A` - Open AI browser
- **Shortcuts Display**: View all shortcuts in Settings section

### Additional Hook DLL
- **hook_antiinterview.dll**: Hide AI browser process from Task Manager
- **Total Hooks**: 7 specialized DLLs for different processes

---

## Technical Improvements

### Architecture
- **WRY/WebView2 Integration**: Modern web rendering engine
- **Arboard Library**: Cross-platform clipboard support
- **Separate Process**: AI browser runs as standalone process (ai_browser_window.exe)
- **Thread-Safe State**: Arc<Mutex<bool>> for browser state management

### Testing
- **96 Total Tests**: All passing
- **15 New Clipboard Tests**: Comprehensive coverage of clipboard operations
- **Test Categories**:
  - Image data structure validation
  - Clipboard operations (set, get, clear)
  - RGBA format preservation
  - Configuration integration
  - Concurrent access handling

### Build System
- **Multi-Binary Support**: Main app + AI browser window
- **DLL Management**: Automatic utils.dll placement
- **Release Packaging**: Updated scripts for new binaries

---

## Configuration Changes

### New Settings
```toml
[ui]
auto_paste_screenshot = false  # Auto-copy screenshot to clipboard
auto_hide_ai_browser = true    # Auto-hide AI browser windows

[hotkeys]
silent_screenshot = "Ctrl+Shift+P"
refresh_windows = "Ctrl+Shift+R"
toggle_preview = "Ctrl+Shift+V"
open_ai_browser = "Ctrl+Shift+A"
```

---

## Bug Fixes

### Window Hiding
- **Fixed**: utils.dll not found in release builds
- **Solution**: Proper DLL path resolution for both debug and release
- **Impact**: Window hiding now works reliably

### Browser State Management
- **Fixed**: Browser state remained "open" after closing window
- **Solution**: Background thread monitors process with `child.wait()`
- **Impact**: Can reopen browser after closing

### Clipboard Operations
- **Fixed**: Windows clipboard timing issues in tests
- **Solution**: Graceful error handling with Result patterns
- **Impact**: Stable test suite on Windows

---

## Performance

- **Zero-Cost Abstractions**: Rust iterators and borrowing
- **Minimal Allocations**: Pre-allocated buffers where possible
- **Async Operations**: Non-blocking browser window spawning
- **Memory Efficient**: Cow<[u8]> for clipboard data

---

## Dependencies

### New Dependencies
- `wry = "0.55"` - WebView2 wrapper
- `tao = "0.30"` - Window management for WRY
- `arboard = "3"` - Clipboard operations

### Updated Dependencies
- All dependencies updated to latest stable versions

---

## Breaking Changes

None. Fully backward compatible with v1.0.0 configurations.

---

## Known Issues

- **Clipboard Copy**: Requires `auto_paste_screenshot` enabled in settings
- **WebView2**: Requires Microsoft Edge WebView2 Runtime (auto-installed on Windows 10/11)
- **Admin Rights**: Required for DLL injection and Task Manager hooks

---

## Migration Guide

### From v1.0.0 to v1.1.0

1. **No action required** - Configuration auto-migrates
2. **Optional**: Enable `auto_paste_screenshot` in settings for clipboard copy
3. **Optional**: Disable `auto_hide_ai_browser` if you want browser visible in captures

---

## Installation

### Portable ZIP
1. Extract `anti-interview-v1.1.0-portable.zip`
2. Run `anti-interview.exe` as administrator
3. All DLLs included in package

### Installer
1. Run `anti-interview-setup-v1.1.0.exe`
2. Follow installation wizard
3. Launch from Start Menu or Desktop

---

## File Manifest

### Executables
- `anti-interview.exe` (23.8 MB) - Main application
- `ai_browser_window.exe` (15.2 MB) - AI browser window

### DLLs
- `utils.dll` (237 KB) - Window manipulation payload
- `hook_notepad.dll` - Notepad process hiding
- `hook_firefox.dll` - Firefox process hiding
- `hook_edge.dll` - Edge process hiding
- `hook_chrome.dll` - Chrome process hiding
- `hook_vscode.dll` - VS Code process hiding
- `hook_visualstudio.dll` - Visual Studio process hiding
- `hook_antiinterview.dll` - AI browser process hiding

### Documentation
- `README.md` - User guide
- `LICENSE` - MIT License
- `RELEASE_NOTES.md` - This file
- `RELEASE_NOTES_PT.md` - Portuguese version

---

## Credits

**Developed by**: Matheus & Pyetrah (Designer)

**Special Thanks**:
- Radiantly - InvisWind inspiration
- OpenByteDev - dll-syringe library
- egui community - UI framework
- WRY team - WebView2 integration

---

## Support

- **Issues**: https://github.com/yourusername/anti-interview/issues
- **Documentation**: See README.md
- **License**: MIT

---

## Checksums (SHA256)

```
anti-interview.exe: [to be generated]
ai_browser_window.exe: [to be generated]
utils.dll: [to be generated]
```

---

## Next Release (v1.2.0)

Planned features:
- UI for hotkey customization
- Window profiles
- Auto-hide rules
- Start with Windows
- Cursor hiding
