# Anti-Interview v1.1.0 - Notas de Lançamento

## Data de Lançamento: 31 de Março de 2026

---

## Novos Recursos

### Integração com Navegador AI
- **Janela de Navegador Integrada**: Acesse plataformas de IA sem abrir navegador externo
  - ChatGPT (https://chatgpt.com)
  - Antigravity (https://antigravity.ai)
  - Gemini (https://gemini.google.com)
  - Claude (https://claude.ai)
- **Janelas Sem Bordas**: Aparência profissional com barra de título personalizada
- **Monitoramento de Processo**: Sincronização automática de estado quando navegador fecha
- **Suporte Auto-Ocultar**: Oculta automaticamente janelas do navegador AI da captura de tela

### Screenshot Silencioso com Área de Transferência
- **Novo Atalho**: `Ctrl+Shift+P` para screenshot silencioso
- **Integração com Área de Transferência**: Copia automaticamente imagem (não caminho do arquivo)
- **Configurável**: Ative/desative auto-colar nas configurações
- **Formato RGBA**: Suporte completo a cores com canal alfa
- **Armazenamento Temporário**: Screenshots salvos em diretório temp com timestamp

### Sistema de Atalhos Aprimorado
- **7 Atalhos Configuráveis**:
  - `Ctrl+Shift+S` - Screenshot normal
  - `Ctrl+Shift+P` - Screenshot silencioso (cópia para área de transferência)
  - `Ctrl+Shift+H` - Ocultar janela selecionada
  - `Ctrl+Shift+I` - Mostrar/Ocultar GUI
  - `Ctrl+Shift+R` - Atualizar lista de janelas
  - `Ctrl+Shift+V` - Alternar preview
  - `Ctrl+Shift+A` - Abrir navegador AI
- **Exibição de Atalhos**: Visualize todos os atalhos na seção Configurações

### DLL de Hook Adicional
- **hook_antiinterview.dll**: Oculta processo do navegador AI do Gerenciador de Tarefas
- **Total de Hooks**: 7 DLLs especializadas para diferentes processos

---

## Melhorias Técnicas

### Arquitetura
- **Integração WRY/WebView2**: Motor de renderização web moderno
- **Biblioteca Arboard**: Suporte multiplataforma para área de transferência
- **Processo Separado**: Navegador AI roda como processo standalone (ai_browser_window.exe)
- **Estado Thread-Safe**: Arc<Mutex<bool>> para gerenciamento de estado do navegador

### Testes
- **96 Testes Totais**: Todos passando
- **15 Novos Testes de Área de Transferência**: Cobertura abrangente de operações
- **Categorias de Teste**:
  - Validação de estrutura de dados de imagem
  - Operações de área de transferência (set, get, clear)
  - Preservação de formato RGBA
  - Integração de configuração
  - Tratamento de acesso concurrent

### Sistema de Build
- **Suporte Multi-Binário**: App principal + janela do navegador AI
- **Gerenciamento de DLL**: Posicionamento automático de utils.dll
- **Empacotamento de Release**: Scripts atualizados para novos binários

---

## Mudanças de Configuração

### Novas Configurações
```toml
[ui]
auto_paste_screenshot = false  # Auto-copiar screenshot para área de transferência
auto_hide_ai_browser = true    # Auto-ocultar janelas do navegador AI

[hotkeys]
silent_screenshot = "Ctrl+Shift+P"
refresh_windows = "Ctrl+Shift+R"
toggle_preview = "Ctrl+Shift+V"
open_ai_browser = "Ctrl+Shift+A"
```

---

## Correções de Bugs

### Ocultação de Janelas
- **Corrigido**: utils.dll não encontrada em builds de release
- **Solução**: Resolução adequada de caminho de DLL para debug e release
- **Impacto**: Ocultação de janelas agora funciona de forma confiável

### Gerenciamento de Estado do Navegador
- **Corrigido**: Estado do navegador permanecia "aberto" após fechar janela
- **Solução**: Thread em background monitora processo com `child.wait()`
- **Impacto**: Pode reabrir navegador após fechar

### Operações de Área de Transferência
- **Corrigido**: Problemas de timing da área de transferência do Windows em testes
- **Solução**: Tratamento gracioso de erros com padrões Result
- **Impacto**: Suite de testes estável no Windows

---

## Performance

- **Abstrações Zero-Cost**: Iteradores e borrowing do Rust
- **Alocações Mínimas**: Buffers pré-alocados quando possível
- **Operações Assíncronas**: Spawn não-bloqueante de janela do navegador
- **Eficiência de Memória**: Cow<[u8]> para dados da área de transferência

---

## Dependências

### Novas Dependências
- `wry = "0.55"` - Wrapper WebView2
- `tao = "0.30"` - Gerenciamento de janelas para WRY
- `arboard = "3"` - Operações de área de transferência

### Dependências Atualizadas
- Todas as dependências atualizadas para versões estáveis mais recentes

---

## Mudanças Incompatíveis

Nenhuma. Totalmente compatível com configurações v1.0.0.

---

## Problemas Conhecidos

- **Cópia para Área de Transferência**: Requer `auto_paste_screenshot` habilitado nas configurações
- **WebView2**: Requer Microsoft Edge WebView2 Runtime (auto-instalado no Windows 10/11)
- **Direitos de Administrador**: Necessário para injeção de DLL e hooks do Task Manager

---

## Guia de Migração

### De v1.0.0 para v1.1.0

1. **Nenhuma ação necessária** - Configuração migra automaticamente
2. **Opcional**: Habilite `auto_paste_screenshot` nas configurações para cópia para área de transferência
3. **Opcional**: Desabilite `auto_hide_ai_browser` se quiser navegador visível em capturas

---

## Instalação

### ZIP Portátil
1. Extraia `anti-interview-v1.1.0-portable.zip`
2. Execute `anti-interview.exe` como administrador
3. Todas as DLLs incluídas no pacote

### Instalador
1. Execute `anti-interview-setup-v1.1.0.exe`
2. Siga o assistente de instalação
3. Inicie pelo Menu Iniciar ou Área de Trabalho

---

## Manifesto de Arquivos

### Executáveis
- `anti-interview.exe` (23.8 MB) - Aplicação principal
- `ai_browser_window.exe` (15.2 MB) - Janela do navegador AI

### DLLs
- `utils.dll` (237 KB) - Payload de manipulação de janelas
- `hook_notepad.dll` - Ocultação de processo Notepad
- `hook_firefox.dll` - Ocultação de processo Firefox
- `hook_edge.dll` - Ocultação de processo Edge
- `hook_chrome.dll` - Ocultação de processo Chrome
- `hook_vscode.dll` - Ocultação de processo VS Code
- `hook_visualstudio.dll` - Ocultação de processo Visual Studio
- `hook_antiinterview.dll` - Ocultação de processo navegador AI

### Documentação
- `README.md` - Guia do usuário
- `LICENSE` - Licença MIT
- `RELEASE_NOTES.md` - Versão em inglês
- `RELEASE_NOTES_PT.md` - Este arquivo

---

## Créditos

**Desenvolvido por**: Matheus & Pyetrah (Designer)

**Agradecimentos Especiais**:
- Radiantly - Inspiração InvisWind
- OpenByteDev - Biblioteca dll-syringe
- Comunidade egui - Framework de UI
- Time WRY - Integração WebView2

---

## Suporte

- **Issues**: https://github.com/yourusername/anti-interview/issues
- **Documentação**: Veja README.md
- **Licença**: MIT

---

## Checksums (SHA256)

```
anti-interview.exe: [a ser gerado]
ai_browser_window.exe: [a ser gerado]
utils.dll: [a ser gerado]
```

---

## Próximo Lançamento (v1.2.0)

Recursos planejados:
- UI para customização de atalhos
- Perfis de janelas
- Regras de auto-ocultação
- Iniciar com o Windows
- Ocultação de cursor
